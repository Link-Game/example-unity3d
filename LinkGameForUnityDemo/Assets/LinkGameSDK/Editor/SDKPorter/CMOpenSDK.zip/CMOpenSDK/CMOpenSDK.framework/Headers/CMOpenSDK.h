//
//  CMOpenSDK.h
//  CMOpenSDK
//
//  Created by 刘万林 on 2018/3/2.
//  Copyright © 2018年 刘万林. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CMOpenSDK/CMRequest.h>
#import <CMOpenSDK/CMResponse.h>

//! Project version number for CMOpenSDK.
FOUNDATION_EXPORT double CMOpenSDKVersionNumber;

//! Project version string for CMOpenSDK.
FOUNDATION_EXPORT const unsigned char CMOpenSDKVersionString[];

@protocol CMOpenSDKDelegate<NSObject>

-(void)didResponsed:(CMBaseResponse * )response;
@end

/**
 开放平台SDK
 */
@interface CMOpenSDK:NSObject

/**
 获得SDK单例
 */
+(instancetype)share;

/**
 注册App

 @param appID 开放平台提供的AppID
 @param appSecret 开放平台提供的AppSecret
 @param delegate 响应回调的delegate
 */
-(void)RegisterAppID:(NSString *)appID AppSecret:(NSString *)appSecret Delegate:(id<CMOpenSDKDelegate>)delegate;

/**
 向游戏互联发送一个请求

 @param request 请求
 @return 是否成功
 */
-(BOOL)sendRequest:(CMBaseRequest *)request;

/**
 判断是否安装游戏互联
 需要将 cmsyyouxihulian 加入URLScheme白名单

 @return 是否安装游戏互联
 */
-(BOOL)isInstallYXHL;
@end

